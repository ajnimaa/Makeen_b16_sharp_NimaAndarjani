<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphToMany;

class Media extends Model
{
    use HasFactory;

    protected $fillable = [
        'file_name',
        'size',
        'path',
        'type',
        'extension'
    ];

    public function products(): MorphToMany
    {
        return $this->morphedByMany(Product::class, 'mediable');
    }

    public function users(): MorphToMany
    {
        return $this->morphedByMany(User::class, 'mediable');
    }

    public function factors(): MorphToMany
    {
        return $this->morphedByMany(Factor::class, 'mediable');
    }
}
