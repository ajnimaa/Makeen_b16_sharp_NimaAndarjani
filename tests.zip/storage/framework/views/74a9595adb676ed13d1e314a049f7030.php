<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>لیست دسته بندی ها</title>
</head>
<body>
<h1>لیست دسته بندی ها</h1>
    <table border="1" style="width:700px">
        <thead>
            <tr>
                <th>category id</th>
                <th>category name</th>
                <th>manage</th>
            </tr>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th>
                        <button><a href="">ویرایش</a></button>
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit">حذف</button>
                        </form>
                    </th>
                </tr>
        </thead>
    </table>
</body>
</html>
<?php /**PATH D:\project\laravel\crm\resources\views/category/index.blade.php ENDPATH**/ ?>