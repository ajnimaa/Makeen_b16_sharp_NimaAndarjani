<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ویرایش محصول</title>
</head>
<body>
    <h1>ویرایش محصول</h1>
<form action="/products/edit/<?php echo e($product->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="product_name" value="<?php echo e($product ->product_name); ?>">
    <br>
    <input type="text" name="product_code" value="<?php echo e($product ->product_code); ?>">
    <br>
    <input type="text" name="product_price" value="<?php echo e($product ->product_price); ?>">
    <br>
    <input type="text" name="inventory" value="<?php echo e($product ->inventory); ?>">
    <br>
    <button type="submit">ویرایش</button>
</form>
</body>
</html>
<?php /**PATH D:\project\laravel\crm\resources\views/products/edit.blade.php ENDPATH**/ ?>