<html lang="en" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ویرایش مقاله</title>
</head>

<body>
    <h1>ویرایش مقاله</h1>
    <br>
    <form action="/post/edit/<?php echo e($post->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="post_subject" value="<?php echo e($post->post_subject); ?>" placeholder="موضوع مقاله">
        <br>
        <input type="text" name="post_text" value="<?php echo e($post->post_text); ?>" placeholder="متن مقاله">
        <br>
        <select name="category_id">
            <option value="pezeshki" <?php echo e($post->category_id == 'pezeshki' ? 'selected' : ''); ?>>پزشکی</option>
            <option value="varzeshi" <?php echo e($post->category_id == 'varzeshi' ? 'selected' : ''); ?>>ورزشی</option>
            <option value="elmi" <?php echo e($post->category_id == 'elmi' ? 'selected' : ''); ?>>علمی</option>
            <option value="siyasi" <?php echo e($post->category_id == 'siyasi' ? 'selected' : ''); ?>>سیاسی</option>
        </select>
        <button type="submit">ثبت</button>
    </form>
</body>

</html>
<?php /**PATH D:\project\laravel\crm\resources\views/posts/edit.blade.php ENDPATH**/ ?>