<html lang="en" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>وبلاگ</title>
</head>

<body>
    <h1>وبلاگ</h1>
    <table border="1" style="width:700px">
        <thead>
            <tr>
                <th>عنوان مقاله</th>
                <th>دسته بندی</th>
                <th>متن مقاله</th>
                <th>manage</th>
            </tr>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($post->post_subject); ?></th>
                    <th><?php echo e($post->category_id); ?></th>
                    <th><?php echo e($post->post_text); ?></th>
                    <th>
                        <button><a href="/post/edit/<?php echo e($post->id); ?>">ویرایش</a></button>
                        <form action="/posts/delete/<?php echo e($post->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit">حذف</button>
                        </form>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </thead>
    </table>
</body>

</html>
<?php /**PATH D:\project\laravel\crm\resources\views/posts/index.blade.php ENDPATH**/ ?>