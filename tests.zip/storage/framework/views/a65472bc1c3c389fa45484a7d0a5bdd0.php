<html lang="en" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ویرایش کاربر</title>
</head>

<body>
    <h1>ویرایش کاربر</h1>
    <br>
    <form action="/users/edit/<?php echo e($users->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" value="<?php echo e($users->name); ?>" placeholder="نام">
        <br>
        <input type="text" name="last_name" value="<?php echo e($users->last_name); ?>" placeholder="نام خانوادگی">
        <br>
        <input type="number" name="phone_number" value="<?php echo e($users->phone_number); ?>" placeholder="شماره موبایل">
        <br>
        <input type="email" name="email" value="<?php echo e($users->email); ?>" placeholder="ایمیل">
        <br>
        <select name="gender">
            <option value="male" <?php echo e($users->gender == 'male' ? 'selected' : ''); ?>>male</option>
            <option value="female" <?php echo e($users->gender == 'female' ? 'selected' : ''); ?>>female</option>
        </select>
        <br>
        <button type="submit">ثبت</button>
    </form>
</body>

</html>
<?php /**PATH D:\project\laravel\crm\resources\views/users/edit.blade.php ENDPATH**/ ?>