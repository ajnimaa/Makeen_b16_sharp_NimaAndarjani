<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>لیست سفارشات</title>
</head>
<body>
<h1>لیست سفارشات</h1>
<table border="1" style="width:700px">
    <thead>
        <tr>
            <th>ردیف</th>
            <th>سفارش</th>
            <th>کد سفارش</th>
            <th>تاریخ تحویل سفارش</th>
            <th>روش تحویل</th>
            <th>manage</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <tr>
            <th><?php echo e($order->id); ?></th>
            <th><?php echo e($order->order_name); ?></th>
            <th><?php echo e($order->order_code); ?></th>
            <th><?php echo e($order->order_delivery_time); ?></th>
            <th><?php echo e($order->delivery_method); ?></th>
            <th>
                <button><a href="/orders/edit/<?php echo e($order->id); ?>">ویرایش</a></button>
                <form action="/orders/delete/<?php echo e($order->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit">حذف</button>
                </form>
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</thead>
</table>
<a href="./add"><button>افزودن سفارش</button></a>
</body>
</html>
<?php /**PATH D:\project\laravel\crm\resources\views/orders/index.blade.php ENDPATH**/ ?>